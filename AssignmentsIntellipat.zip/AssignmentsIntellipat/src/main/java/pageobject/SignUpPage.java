package pageobject;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidArgumentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import reusable.BaseCode;
import reusable.ReadExcelData;

import java.io.IOException;

public class SignUpPage extends BaseCode {


    public static void clickOnCreateNewAccount() throws InterruptedException {

        driver.findElement(By.partialLinkText("Create")).click();
        Thread.sleep(3000);

    }


    public static void enterValidCredentials() throws IOException, InterruptedException {
        driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys(ReadExcelData.excelData("Sheet1", 0, 0));
        Thread.sleep(3000);
        driver.findElement(By.name("lastname")).sendKeys(ReadExcelData.excelData("Sheet1", 1, 0));
        Thread.sleep(3000);
        driver.findElement(By.name("reg_email__")).sendKeys(ReadExcelData.excelData("Sheet1", 2, 0));
        Thread.sleep(3000);
        driver.findElement(By.id("password_step_input")).sendKeys(ReadExcelData.excelData("Sheet1", 3, 0));
        Thread.sleep(3000);
    }

    public static void selectDOB() throws IOException {
        WebElement wb = driver.findElement(By.name("birthday_day"));
        Select dt = new Select(wb);
        dt.selectByVisibleText(ReadExcelData.excelData("Sheet1", 4, 0));
        WebElement wb1 = driver.findElement(By.name("birthday_month"));
        Select dy = new Select(wb1);
        dy.selectByVisibleText(ReadExcelData.excelData("Sheet1", 5, 0));
        WebElement wb2 = driver.findElement(By.name("birthday_year"));
        Select yr = new Select(wb2);
        yr.selectByVisibleText(ReadExcelData.excelData("Sheet1", 6, 0));
    }


    public static void selectGender() throws IOException {
        if (ReadExcelData.excelData("Sheet1", 7, 0).equals("Female"))
        {

            driver.findElement(By.xpath("//input[@value='1']")).click();
        }

        else if(ReadExcelData.excelData("Sheet1", 7, 0).equals("Male"))
        {

        driver.findElement(By.xpath("//input[@value='2']")).click();
        }

        else if(ReadExcelData.excelData("Sheet1", 7, 0).equals("Custom"))
        {

            driver.findElement(By.xpath("//input[@value='3']")).click();
        }
        else
        {
            throw new InvalidArgumentException("Enter valid gender");
        }

}


 public static void clickSignUp()
 {
    driver.findElement(By.name("websubmit")).click();
 }
 }