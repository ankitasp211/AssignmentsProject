package stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pageobject.SignUpPage;

import java.io.IOException;

public class SearchingElementXPathM4 {

    @Given("User enters valid credentials")
    public void enterCredentials() throws IOException, InterruptedException {
        SignUpPage.clickOnCreateNewAccount();
        SignUpPage.enterValidCredentials();
        SignUpPage.selectDOB();
        SignUpPage.selectGender();


    }

    @When("User clicks on Sign Up button")
    public void userClicksOnSignUpButton() {
        SignUpPage.clickSignUp();

    }
}

